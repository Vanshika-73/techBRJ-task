For running this form in your local pc:
kindly first run the following command in your terminal:
1. npm install 
2. npm start