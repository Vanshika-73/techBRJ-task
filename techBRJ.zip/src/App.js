import React from 'react';
import Form from './Components/Form';
const App = () => {
  return (
    <Form/>
  );
}

export default App;
